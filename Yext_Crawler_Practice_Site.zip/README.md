# Northstar Home Stores — Yext Crawler Practice Site

This is a fictional, static HTML training site for practicing a Yext Crawler source.
All business details are invented. The `.example` links are placeholders and are not intended to resolve.

## Publish it so Yext can crawl it
1. Create a new public GitHub repository, e.g. `yext-crawler-practice`.
2. Upload the contents of the `site` folder (not the parent folder) to the repository root.
3. In repository Settings → Pages, publish from the `main` branch and `/ (root)`.
4. Wait until GitHub Pages gives you a public URL. Open the home page and `stores.html` in a browser.
5. Use that published URL as the crawler start URL in Yext.

Do not use the local file path or a `file://` URL in Yext; the crawler needs a publicly accessible HTTP(S) URL.
